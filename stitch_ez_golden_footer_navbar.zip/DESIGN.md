---
name: Lumina Learning
colors:
  surface: '#0b1326'
  surface-dim: '#0b1326'
  surface-bright: '#31394d'
  surface-container-lowest: '#060e20'
  surface-container-low: '#131b2e'
  surface-container: '#171f33'
  surface-container-high: '#222a3d'
  surface-container-highest: '#2d3449'
  on-surface: '#dae2fd'
  on-surface-variant: '#cec6ac'
  inverse-surface: '#dae2fd'
  inverse-on-surface: '#283044'
  outline: '#979179'
  outline-variant: '#4c4733'
  surface-tint: '#e2c60f'
  primary: '#fffdff'
  on-primary: '#393000'
  primary-container: '#ffe135'
  on-primary-container: '#736300'
  inverse-primary: '#6d5e00'
  secondary: '#a4c9ff'
  on-secondary: '#00315d'
  secondary-container: '#0164b4'
  on-secondary-container: '#d0e1ff'
  tertiary: '#fcfff1'
  on-tertiary: '#1c3700'
  tertiary-container: '#a0f848'
  on-tertiary-container: '#3d7000'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffe245'
  primary-fixed-dim: '#e2c60f'
  on-primary-fixed: '#211b00'
  on-primary-fixed-variant: '#524700'
  secondary-fixed: '#d4e3ff'
  secondary-fixed-dim: '#a4c9ff'
  on-secondary-fixed: '#001c39'
  on-secondary-fixed-variant: '#004883'
  tertiary-fixed: '#a1fa49'
  tertiary-fixed-dim: '#87dc2c'
  on-tertiary-fixed: '#0e2000'
  on-tertiary-fixed-variant: '#2a5000'
  background: '#0b1326'
  on-background: '#dae2fd'
  surface-variant: '#2d3449'
typography:
  display-lg:
    fontFamily: Be Vietnam Pro
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
  headline-md:
    fontFamily: Be Vietnam Pro
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
  headline-sm:
    fontFamily: Be Vietnam Pro
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Be Vietnam Pro
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Be Vietnam Pro
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: Be Vietnam Pro
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  headline-md-mobile:
    fontFamily: Be Vietnam Pro
    fontSize: 22px
    fontWeight: '700'
    lineHeight: 28px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  container-margin: 1.5rem
  stack-gap: 1rem
  card-padding: 1.5rem
  nav-height: 80px
  icon-size-nav: 24px
---

## Brand & Style
The design system is built for a focused, high-energy educational environment. It utilizes a **Corporate / Modern** foundation with **Tactile** influences, specifically through high-contrast surfaces and extremely generous rounded corners. 

The personality is encouraging and structured. It targets adult learners who appreciate a clean, dark-mode-first interface that reduces eye strain while maintaining clear visual hierarchy through vibrant accent colors. The aesthetic is defined by "nested depth"—where white high-contrast cards sit atop a deep obsidian background, creating a physical sense of layers and focus.

## Colors
The palette is rooted in a deep navy/black neutral (`#0B101B`), which acts as the infinite canvas. Key interactive and informational elements utilize high-saturation primary colors:
- **Primary (Yellow):** Used for critical focus points, active states, and call-to-action highlights.
- **Secondary (Blue/Green):** Used for categorical distinction (e.g., level indicators like N4 or N5) and progress tracking.
- **Surface Strategy:** This system employs a high-contrast reversal. While the background is dark, the primary content containers are pure white (`#FFFFFF`) to ensure maximum legibility for body text and educational content.
- **Navigation:** The footer and header utilize a slightly elevated charcoal (`#1A2234`) to separate global controls from the content area.

## Typography
We use **Be Vietnam Pro** across the entire system to maintain a contemporary, friendly, and highly legible tone. 

- **Weight Usage:** Bold (700) is reserved for section headers and primary card titles. Semi-bold (600) is used for labels and secondary navigation. 
- **Contrast:** On dark surfaces, use White. On white cards, use a dark Slate (`#1E293B`) for titles and a lighter gray (`#64748B`) for descriptive subtext.
- **Hierarchy:** Large display text should be used sparingly for greetings or milestone celebrations.

## Layout & Spacing
The layout follows a **fluid grid** model with strict horizontal safe areas.
- **Vertical Rhythm:** A consistent 16px (1rem) gap is used between cards to create a clear stack.
- **Margins:** 24px (1.5rem) side margins are maintained on mobile to ensure content doesn't feel cramped against the screen edges.
- **Navigation:** The footer is fixed to the bottom, using an 80px height to accommodate comfortable thumb tap targets. Icons within the footer should be centered within 48x48px hit areas.

## Elevation & Depth
Depth is expressed through **Tonal Layers** and **Hard Shadows**:
- **Layer 0:** The base background (`#0B101B`).
- **Layer 1 (Global Nav):** A subtle elevation using `#1A2234` with no shadow, but a distinct top border (`1px solid #2D3748`) to define the footer boundary.
- **Layer 2 (Cards):** Pure white surfaces that "pop" from the background. These do not use soft shadows; instead, they rely on the extreme color contrast and a very subtle 1px stroke in a light gray to define edges against the dark background.

## Shapes
The system is defined by extreme roundedness to feel approachable and "toy-like" (tactile).
- **Cards:** Use `rounded-xl` (1.5rem / 24px) for all primary container corners.
- **Icon Backdrops:** Squircle shapes or heavily rounded boxes (12px) are used to house icons within cards.
- **Navigation Items:** The active state in the footer uses a "pill-frame" (a 12px rounded rectangle border) around the active icon and label.

## Components
### Footer / Bottom Navigation
The footer is a primary component. It features a dark background (`#1A2234`) with icons and labels stacked vertically. 
- **Active State:** The active item is encased in a rounded-rect border (1px) using the Primary Yellow color. The icon and text within the active state also turn Yellow.
- **Inactive State:** Icons and labels use a muted gray/white with ~60% opacity.

### Cards
Cards are the primary content vehicle. 
- **Structure:** A horizontal layout containing a leading icon/badge, a center-aligned text stack (Title + Subtitle), and a trailing chevron for expandability.
- **Internal Accents:** Secondary colors (Blue/Green) are used for "lesson count" labels at the bottom of the card to draw the eye to progress.

### Buttons & Chips
Small utility buttons (like the "Program" or "Logout" buttons in the header) should use a semi-transparent dark fill with a light border, maintaining a low profile compared to the main content cards.