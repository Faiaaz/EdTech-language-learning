---
name: Avatar Progression System
colors:
  surface: '#0b1326'
  surface-dim: '#0b1326'
  surface-bright: '#31394d'
  surface-container-lowest: '#060e20'
  surface-container-low: '#131b2e'
  surface-container: '#171f33'
  surface-container-high: '#222a3d'
  surface-container-highest: '#2d3449'
  on-surface: '#dae2fd'
  on-surface-variant: '#d1c6ab'
  inverse-surface: '#dae2fd'
  inverse-on-surface: '#283044'
  outline: '#9a9078'
  outline-variant: '#4d4632'
  surface-tint: '#eec200'
  primary: '#ffecb9'
  on-primary: '#3c2f00'
  primary-container: '#facc15'
  on-primary-container: '#6c5700'
  inverse-primary: '#735c00'
  secondary: '#adc6ff'
  on-secondary: '#002e6a'
  secondary-container: '#0566d9'
  on-secondary-container: '#e6ecff'
  tertiary: '#f7e8ff'
  on-tertiary: '#490080'
  tertiary-container: '#e4c5ff'
  on-tertiary-container: '#7e23cd'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffe083'
  primary-fixed-dim: '#eec200'
  on-primary-fixed: '#231b00'
  on-primary-fixed-variant: '#574500'
  secondary-fixed: '#d8e2ff'
  secondary-fixed-dim: '#adc6ff'
  on-secondary-fixed: '#001a42'
  on-secondary-fixed-variant: '#004395'
  tertiary-fixed: '#f0dbff'
  tertiary-fixed-dim: '#ddb7ff'
  on-tertiary-fixed: '#2c0051'
  on-tertiary-fixed-variant: '#6900b3'
  background: '#0b1326'
  on-background: '#dae2fd'
  surface-variant: '#2d3449'
typography:
  headline-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '700'
    lineHeight: 24px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '500'
    lineHeight: 24px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  xp-display:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '800'
    lineHeight: 18px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 4px
  xs: 8px
  sm: 12px
  md: 16px
  lg: 24px
  xl: 32px
  container-padding: 20px
  stack-gap: 12px
---

## Brand & Style

The design system is built to foster a sense of adventure, personal growth, and playful achievement. It targets a demographic that values self-expression through digital identity and finds motivation in incremental progress. The emotional response is one of warmth and encouragement, transforming mundane tasks into heroic milestones.

The visual style is a hybrid of **Modern Gamified** and **Glassmorphism**. It utilizes deep, immersive backgrounds to create a "night-mode" focus, allowing vibrant, neon-adjacent accents to guide the user's eye toward calls to action and rewards. The aesthetic avoids the sterility of traditional productivity apps in favor of tactile, "squishy" UI elements that feel reactive and rewarding to interact with.

## Colors

The palette is anchored by a deep navy background that provides high contrast for the energetic yellow primary color. This primary yellow is reserved for significant milestones, active states, and core progression indicators.

Secondary and tertiary colors are used as functional markers for different activity types (e.g., Blue for Quizzes, Green for Games, Purple for Lessons). This color-coding helps users mentally categorize their efforts at a glance. Backgrounds should utilize subtle radial gradients to create a "spotlight" effect behind the avatar, adding depth and a sense of prestige to the character's presentation.

## Typography

The design system utilizes **Plus Jakarta Sans** across all interfaces. Its soft, open counters and rounded terminals provide a friendly and approachable feel that mitigates the potential "hardness" of a dark-themed UI.

Headlines use a bold weight to establish clear hierarchy and a sense of "heroic" scale for achievements. Body text remains medium or regular weight to ensure readability against dark backgrounds. Labels and XP counters utilize semi-bold weights and slightly increased letter spacing to maintain clarity at smaller scales, especially when placed inside colorful badges or chips.

## Layout & Spacing

This design system uses a **Fluid Grid** model optimized for mobile-first interactions. It relies on a consistent 4px baseline shift to maintain a rhythmic vertical flow. 

Content is housed within "Safe Areas" with a standard 20px horizontal margin to prevent UI elements from feeling cramped against screen edges. Spacing between cards (stack-gap) is kept tight at 12px to emphasize the relationship between different journey milestones. Large sections, such as the avatar showcase and the "Journey" list, are separated by 32px of vertical whitespace to provide breathing room and visual distinction between character identity and task progression.

## Elevation & Depth

Visual hierarchy is established through **Tonal Layers** rather than heavy shadows. Since the background is a deep navy, depth is created by lightening the surface color of foreground elements.

1.  **Base Layer:** #0F172A (Deep Navy).
2.  **Surface Layer (Cards):** A slightly lighter navy/grey (e.g., #1E293B) with a subtle 1px border.
3.  **Active State:** Cards representing the "current" level use a 2px solid primary yellow border and a very soft yellow outer glow (10% opacity) to signify the user's present location in the journey.
4.  **Overlays:** High-priority modals use a backdrop blur (12px) to focus the user's attention entirely on the milestone celebration.

## Shapes

The shape language is defined by "soft-edged" geometry. Primary containers and cards use a 1rem (16px) corner radius to feel safe and modern. 

Interactive elements such as buttons, activity chips, and progress badges utilize **Pill-shaped (fully rounded)** corners. This distinction helps the user intuitively differentiate between "information containers" (rounded cards) and "actionable items" (pill-shaped buttons). Progress bars must always have fully rounded caps to maintain the soft, fluid aesthetic of the growth narrative.

## Components

### Buttons & Chips
- **Primary Action:** Pill-shaped, Primary Yellow background with dark navy text.
- **Activity Chips:** Small, pill-shaped badges with a background color corresponding to the activity type (Blue, Green, Purple). Icons within chips should be simplified and playful.
- **Ghost Buttons:** Transparent background with a 1px border and white text for secondary actions like "Reset" or "Info."

### Cards
- **Milestone Cards:** Feature a left-aligned icon (medal or star), a headline, and a sub-description. 
- **Inactive/Locked State:** Use a 40% opacity on text and a grayscale version of the icon to indicate items yet to be reached.

### Progress Indicators
- **XP Bars:** Thin, horizontal tracks. The "filled" portion should use a subtle horizontal gradient (e.g., Secondary Blue to Tertiary Purple) to represent the dynamic nature of growth.

### Avatar Showcase
- The central focus of the app. The avatar is framed by a soft, radial "halo" gradient that matches the current level's theme color, creating a sense of "aura" and importance.